# automated-visual-testing
Code to accompany Test Automation University lecture: Automated Visual Testing
